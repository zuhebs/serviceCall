//
//  ServiceClass.swift
//  ServiceCall
//
//  Created by Zuheb Ali Khan on 01/08/17.
//  Copyright © 2017 Verity Information Solutions. All rights reserved.
//

import Foundation
import Alamofire


struct ServiceClass {
    static let shared = ServiceClass()
    
    
    func serviceCall(baseUrl : String ,parameters : [String : AnyObject]? , completion : @escaping (AnyObject) -> ()){
     
        var url = ""
        
        if parameters != nil && (parameters?.count)! > 0 {
            
           
        }else{
            url = UrlENCoding(url: "\(baseUrl)/")
        }
        

        Alamofire.request(url , method: .get ,parameters: [:],encoding : JSONEncoding.default)
            .validate(statusCode: 200..<300)
            .validate(contentType: ["application/json"])
            .responseData { response in
                if response.result.isSuccess{
                    if let JSON = response.result.value {
                        
                        if let respo = dataEncoding(data: JSON as AnyObject){
                            
                            completion(respo)
                        }
                    }
                }else{
                    completion(response.description as AnyObject)
                }
        }
        
    }
   
}
