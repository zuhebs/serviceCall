//
//  SCollectionViewCell.swift
//  ServiceCall
//
//  Created by Zuheb Ali Khan on 02/08/17.
//  Copyright © 2017 Verity Information Solutions. All rights reserved.
//

import UIKit

class SCollectionViewCell: UICollectionViewCell {
    
}
