//
//  STableViewCell.swift
//  ServiceCall
//
//  Created by Zuheb Ali Khan on 02/08/17.
//  Copyright © 2017 Verity Information Solutions. All rights reserved.
//

import UIKit

class STableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
