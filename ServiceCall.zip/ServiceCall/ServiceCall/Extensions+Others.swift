//
//  Extensions+Others.swift
//  ServiceCall
//
//  Created by Zuheb Ali Khan on 01/08/17.
//  Copyright © 2017 Verity Information Solutions. All rights reserved.
//

import Foundation
import UIKit
import Font_Awesome_Swift
import ACProgressHUD_Swift

func baseUrl() -> String{
    
   // return "https://api.myjson.com/bins/8rbwd"
   // return "http://api.coindesk.com/v1/bpi/currentprice/inr.json"
    return "http://ggservices.veritydemos.com/Administrator.svc/"
}

func dataEncoding(data : AnyObject) -> AnyObject? {
    
    if let dat = data as? NSData{
        do {
            return  try JSONSerialization.jsonObject(with: dat as Data, options: []) as AnyObject
        } catch let error as NSError {
            print(error)
        }
    }
    else{
        return data
    }
    return nil

}

func LoadingViewWithText(text : String , hide : Bool) {
    
    let progressView = ACProgressHUD.shared
    
    if hide {
        progressView.hideHUD()
    }else{
        
        progressView.progressText = text
        progressView.shadowColor = .black
        progressView.indicatorColor = UIColor.gray
        progressView.shadowRadius = 10.0
        progressView.enableBlurBackground = false
        progressView.showHudAnimation = .growIn
        progressView.dismissHudAnimation = .growOut
        progressView.showHUD()
    }
}

func UrlENCoding( url : String) -> String {
    
    return url.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
}
